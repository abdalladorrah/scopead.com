<!doctype html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<title>Page not found &#8211; Salama Engineering</title>
<meta name='robots' content='max-image-preview:large' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	<link rel="alternate" type="application/rss+xml" title="Salama Engineering &raquo; Feed" href="https://salamaeng.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Salama Engineering &raquo; Comments Feed" href="https://salamaeng.com/comments/feed/" />
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/salamaeng.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.7.2"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://salamaeng.com/wp-includes/css/dist/block-library/style.min.css?ver=6.7.2' media='all' />
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='chaty-css-css' href='https://salamaeng.com/wp-content/plugins/chaty-pro/css/chaty-front.min.css?ver=3.31728540281' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://salamaeng.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.9.8' media='all' />
<link rel='stylesheet' id='nbcpf-intlTelInput-style-css' href='https://salamaeng.com/wp-content/plugins/country-phone-field-contact-form-7/assets/css/intlTelInput.min.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='nbcpf-countryFlag-style-css' href='https://salamaeng.com/wp-content/plugins/country-phone-field-contact-form-7/assets/css/countrySelect.min.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='sr7css-css' href='//salamaeng.com/wp-content/plugins/revslider/public/css/sr7.css?ver=6.7.18' media='all' />
<link rel='stylesheet' id='wpos-slick-style-css' href='https://salamaeng.com/wp-content/plugins/timeline-and-history-slider/assets/css/slick.css?ver=2.4.1' media='all' />
<link rel='stylesheet' id='tahs-public-style-css' href='https://salamaeng.com/wp-content/plugins/timeline-and-history-slider/assets/css/slick-slider-style.css?ver=2.4.1' media='all' />
<link rel='stylesheet' id='hello-elementor-css' href='https://salamaeng.com/wp-content/themes/hello-elementor/style.min.css?ver=3.1.1' media='all' />
<link rel='stylesheet' id='hello-elementor-theme-style-css' href='https://salamaeng.com/wp-content/themes/hello-elementor/theme.min.css?ver=3.1.1' media='all' />
<link rel='stylesheet' id='hello-elementor-header-footer-css' href='https://salamaeng.com/wp-content/themes/hello-elementor/header-footer.min.css?ver=3.1.1' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='elementor-post-6-css' href='https://salamaeng.com/wp-content/uploads/elementor/css/post-6.css?ver=1739300893' media='all' />
<link rel='stylesheet' id='jet-popup-frontend-css' href='https://salamaeng.com/wp-content/plugins/jet-popup/assets/css/jet-popup-frontend.css?ver=2.0.6' media='all' />
<link rel='stylesheet' id='widget-icon-list-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='widget-social-icons-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='e-apple-webkit-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/conditionals/apple-webkit.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='widget-image-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/widget-image.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='widget-nav-menu-css' href='https://salamaeng.com/wp-content/plugins/elementor-pro/assets/css/widget-nav-menu.min.css?ver=3.24.2' media='all' />
<link rel='stylesheet' id='widget-heading-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/widget-heading.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='widget-text-editor-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/widget-text-editor.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='widget-icon-box-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/widget-icon-box.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='widget-forms-css' href='https://salamaeng.com/wp-content/plugins/elementor-pro/assets/css/widget-forms.min.css?ver=3.24.2' media='all' />
<link rel='stylesheet' id='flatpickr-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/lib/flatpickr/flatpickr.min.css?ver=4.1.4' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' media='all' />
<link rel='stylesheet' id='e-swiper-css' href='https://salamaeng.com/wp-content/plugins/elementor/assets/css/conditionals/e-swiper.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='https://salamaeng.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.24.2' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='https://salamaeng.com/wp-content/uploads/elementor/css/global.css?ver=1739300894' media='all' />
<link rel='stylesheet' id='elementor-post-9-css' href='https://salamaeng.com/wp-content/uploads/elementor/css/post-9.css?ver=1739300894' media='all' />
<link rel='stylesheet' id='elementor-post-11-css' href='https://salamaeng.com/wp-content/uploads/elementor/css/post-11.css?ver=1739300894' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CDM+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=swap&#038;ver=6.7.2' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script src="https://salamaeng.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://salamaeng.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script src="//salamaeng.com/wp-content/plugins/revslider/public/js/libs/tptools.js?ver=6.7.18" id="tp-tools-js" async data-wp-strategy="async"></script>
<script src="//salamaeng.com/wp-content/plugins/revslider/public/js/sr7.js?ver=6.7.18" id="sr7-js" async data-wp-strategy="async"></script>
<link rel="https://api.w.org/" href="https://salamaeng.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://salamaeng.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.7.2" />
<meta name="cdp-version" content="1.4.9" /><meta name="generator" content="Elementor 3.24.3; features: e_font_icon_svg, additional_custom_breakpoints, e_optimized_control_loading, e_element_cache; settings: css_print_method-external, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<meta name="generator" content="Powered by Slider Revolution 6.7.18 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://salamaeng.com/wp-content/uploads/2024/10/cropped-Salama-Engineering-Website-Favicon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://salamaeng.com/wp-content/uploads/2024/10/cropped-Salama-Engineering-Website-Favicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://salamaeng.com/wp-content/uploads/2024/10/cropped-Salama-Engineering-Website-Favicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://salamaeng.com/wp-content/uploads/2024/10/cropped-Salama-Engineering-Website-Favicon-270x270.png" />
<script>
	window._tpt			??= {};
	window.SR7			??= {};
	_tpt.R				??= {};
	_tpt.R.fonts		??= {};
	_tpt.R.fonts.customFonts??= {};
	SR7.devMode			=  false;
	SR7.F 				??= {};
	SR7.G				??= {};
	SR7.LIB				??= {};
	SR7.E				??= {};
	SR7.E.gAddons		??= {};
	SR7.E.php 			??= {};
	SR7.E.nonce			= '46f50545e1';
	SR7.E.ajaxurl		= 'https://salamaeng.com/wp-admin/admin-ajax.php';
	SR7.E.resturl		= 'https://salamaeng.com/wp-json/';
	SR7.E.slug_path		= 'revslider/revslider.php';
	SR7.E.slug			= 'revslider';
	SR7.E.plugin_url	= 'https://salamaeng.com/wp-content/plugins/revslider/';
	SR7.E.wp_plugin_url = 'https://salamaeng.com/wp-content/plugins/';
	SR7.E.revision		= '6.7.18';
	SR7.E.fontBaseUrl	= '//fonts.googleapis.com/css2?family=';
	SR7.G.breakPoints 	= [1240,1024,778,480];
	SR7.E.modules 		= ['module','page','slide','layer','draw','animate','srtools','canvas','defaults','carousel','navigation','media','modifiers','migration'];
	SR7.E.libs 			= ['WEBGL'];
	SR7.E.css 			= ['csslp','cssbtns','cssfilters','cssnav','cssmedia'];
	SR7.E.resources		= {};
	SR7.JSON			??= {};
/*! Slider Revolution 7.0 - Page Processor */
!function(){"use strict";window.SR7??={},window._tpt??={},SR7.version="Slider Revolution 6.7.16",_tpt.getWinDim=function(t){_tpt.screenHeightWithUrlBar??=window.innerHeight;let e=SR7.F?.modal?.visible&&SR7.M[SR7.F.module.getIdByAlias(SR7.F.modal.requested)];_tpt.scrollBar=window.innerWidth!==document.documentElement.clientWidth||e&&window.innerWidth!==e.c.module.clientWidth,_tpt.winW=window.innerWidth-(_tpt.scrollBar||"prepare"==t?_tpt.scrollBarW??_tpt.mesureScrollBar():0),_tpt.winH=window.innerHeight,_tpt.winWAll=document.documentElement.clientWidth},_tpt.getResponsiveLevel=function(t,e){SR7.M[e];return _tpt.closestGE(t,_tpt.winWAll)},_tpt.mesureScrollBar=function(){let t=document.createElement("div");return t.className="RSscrollbar-measure",t.style.width="100px",t.style.height="100px",t.style.overflow="scroll",t.style.position="absolute",t.style.top="-9999px",document.body.appendChild(t),_tpt.scrollBarW=t.offsetWidth-t.clientWidth,document.body.removeChild(t),_tpt.scrollBarW},_tpt.loadCSS=async function(t,e,s){return s?_tpt.R.fonts.required[e].status=1:(_tpt.R[e]??={},_tpt.R[e].status=1),new Promise(((n,i)=>{if(_tpt.isStylesheetLoaded(t))s?_tpt.R.fonts.required[e].status=2:_tpt.R[e].status=2,n();else{const l=document.createElement("link");l.rel="stylesheet";let o="text",r="css";l["type"]=o+"/"+r,l.href=t,l.onload=()=>{s?_tpt.R.fonts.required[e].status=2:_tpt.R[e].status=2,n()},l.onerror=()=>{s?_tpt.R.fonts.required[e].status=3:_tpt.R[e].status=3,i(new Error(`Failed to load CSS: ${t}`))},document.head.appendChild(l)}}))},_tpt.addContainer=function(t){const{tag:e="div",id:s,class:n,datas:i,textContent:l,iHTML:o}=t,r=document.createElement(e);if(s&&""!==s&&(r.id=s),n&&""!==n&&(r.className=n),i)for(const[t,e]of Object.entries(i))"style"==t?r.style.cssText=e:r.setAttribute(`data-${t}`,e);return l&&(r.textContent=l),o&&(r.innerHTML=o),r},_tpt.collector=function(){return{fragment:new DocumentFragment,add(t){var e=_tpt.addContainer(t);return this.fragment.appendChild(e),e},append(t){t.appendChild(this.fragment)}}},_tpt.isStylesheetLoaded=function(t){let e=t.split("?")[0];return Array.from(document.querySelectorAll('link[rel="stylesheet"], link[rel="preload"]')).some((t=>t.href.split("?")[0]===e))},_tpt.preloader={requests:new Map,preloaderTemplates:new Map,show:function(t,e){if(!e||!t)return;const{type:s,color:n}=e;if(s<0||"off"==s)return;const i=`preloader_${s}`;let l=this.preloaderTemplates.get(i);l||(l=this.build(s,n),this.preloaderTemplates.set(i,l)),this.requests.has(t)||this.requests.set(t,{count:0});const o=this.requests.get(t);clearTimeout(o.timer),o.count++,1===o.count&&(o.timer=setTimeout((()=>{o.preloaderClone=l.cloneNode(!0),o.anim&&o.anim.kill(),void 0!==_tpt.gsap?o.anim=_tpt.gsap.fromTo(o.preloaderClone,1,{opacity:0},{opacity:1}):o.preloaderClone.classList.add("sr7-fade-in"),t.appendChild(o.preloaderClone)}),150))},hide:function(t){if(!this.requests.has(t))return;const e=this.requests.get(t);e.count--,e.count<0&&(e.count=0),e.anim&&e.anim.kill(),0===e.count&&(clearTimeout(e.timer),e.preloaderClone&&(e.preloaderClone.classList.remove("sr7-fade-in"),e.anim=_tpt.gsap.to(e.preloaderClone,.3,{opacity:0,onComplete:function(){e.preloaderClone.remove()}})))},state:function(t){if(!this.requests.has(t))return!1;return this.requests.get(t).count>0},build:(t,e="#ffffff",s="")=>{if(t<0||"off"===t)return null;const n=parseInt(t);if(t="prlt"+n,isNaN(n))return null;if(_tpt.loadCSS(SR7.E.plugin_url+"public/css/preloaders/t"+n+".css","preloader_"+t),isNaN(n)||n<6){const i=`background-color:${e}`,l=1===n||2==n?i:"",o=3===n||4==n?i:"",r=_tpt.collector();["dot1","dot2","bounce1","bounce2","bounce3"].forEach((t=>r.add({tag:"div",class:t,datas:{style:o}})));const d=_tpt.addContainer({tag:"sr7-prl",class:`${t} ${s}`,datas:{style:l}});return r.append(d),d}{let i={};if(7===n){let t;e.startsWith("#")?(t=e.replace("#",""),t=`rgba(${parseInt(t.substring(0,2),16)}, ${parseInt(t.substring(2,4),16)}, ${parseInt(t.substring(4,6),16)}, `):e.startsWith("rgb")&&(t=e.slice(e.indexOf("(")+1,e.lastIndexOf(")")).split(",").map((t=>t.trim())),t=`rgba(${t[0]}, ${t[1]}, ${t[2]}, `),t&&(i.style=`border-top-color: ${t}0.65); border-bottom-color: ${t}0.15); border-left-color: ${t}0.65); border-right-color: ${t}0.15)`)}else 12===n&&(i.style=`background:${e}`);const l=[10,0,4,2,5,9,0,4,4,2][n-6],o=_tpt.collector(),r=o.add({tag:"div",class:"sr7-prl-inner",datas:i});Array.from({length:l}).forEach((()=>r.appendChild(o.add({tag:"span",datas:{style:`background:${e}`}}))));const d=_tpt.addContainer({tag:"sr7-prl",class:`${t} ${s}`});return o.append(d),d}}},SR7.preLoader={show:(t,e)=>{"off"!==(SR7.M[t]?.settings?.pLoader?.type??"off")&&_tpt.preloader.show(e||SR7.M[t].c.module,SR7.M[t]?.settings?.pLoader??{color:"#fff",type:10})},hide:(t,e)=>{"off"!==(SR7.M[t]?.settings?.pLoader?.type??"off")&&_tpt.preloader.hide(e||SR7.M[t].c.module)},state:(t,e)=>_tpt.preloader.state(e||SR7.M[t].c.module)},_tpt.prepareModuleHeight=function(t){window.SR7.M??={},window.SR7.M[t.id]??={},"ignore"==t.googleFont&&(SR7.E.ignoreGoogleFont=!0);let e=window.SR7.M[t.id];if(null==_tpt.scrollBarW&&_tpt.mesureScrollBar(),e.c??={},e.states??={},e.settings??={},e.settings.size??={},t.fixed&&(e.settings.fixed=!0),e.c.module=document.getElementById(t.id),e.c.adjuster=e.c.module.getElementsByTagName("sr7-adjuster")[0],e.c.content=e.c.module.getElementsByTagName("sr7-content")[0],"carousel"==t.type&&(e.c.carousel=e.c.content.getElementsByTagName("sr7-carousel")[0]),null==e.c.module||null==e.c.module)return;t.plType&&t.plColor&&(e.settings.pLoader={type:t.plType,color:t.plColor}),void 0!==t.plType&&"off"!==t.plType&&SR7.preLoader.show(t.id,e.c.module),_tpt.winW||_tpt.getWinDim("prepare"),_tpt.getWinDim();let s=""+e.c.module.dataset?.modal;"modal"==s||"true"==s||"undefined"!==s&&"false"!==s||(e.settings.size.fullWidth=t.size.fullWidth,e.LEV??=_tpt.getResponsiveLevel(window.SR7.G.breakPoints,t.id),t.vpt=_tpt.fillArray(t.vpt,5),e.settings.vPort=t.vpt[e.LEV],void 0!==t.el&&"720"==t.el[4]&&t.gh[4]!==t.el[4]&&"960"==t.el[3]&&t.gh[3]!==t.el[3]&&"768"==t.el[2]&&t.gh[2]!==t.el[2]&&delete t.el,e.settings.size.height=null==t.el||null==t.el[e.LEV]||0==t.el[e.LEV]||"auto"==t.el[e.LEV]?_tpt.fillArray(t.gh,5,-1):_tpt.fillArray(t.el,5,-1),e.settings.size.width=_tpt.fillArray(t.gw,5,-1),e.settings.size.minHeight=_tpt.fillArray(t.mh??[0],5,-1),e.cacheSize={fullWidth:e.settings.size?.fullWidth,fullHeight:e.settings.size?.fullHeight},void 0!==t.off&&(t.off?.t&&(e.settings.size.m??={})&&(e.settings.size.m.t=t.off.t),t.off?.b&&(e.settings.size.m??={})&&(e.settings.size.m.b=t.off.b),t.off?.l&&(e.settings.size.p??={})&&(e.settings.size.p.l=t.off.l),t.off?.r&&(e.settings.size.p??={})&&(e.settings.size.p.r=t.off.r),e.offsetPrepared=!0),_tpt.updatePMHeight(t.id,t,!0))},_tpt.updatePMHeight=(t,e,s)=>{let n=SR7.M[t];var i=n.settings.size.fullWidth?_tpt.winW:n.c.module.parentNode.offsetWidth;i=0===i||isNaN(i)?_tpt.winW:i;let l=n.settings.size.width[n.LEV]||n.settings.size.width[n.LEV++]||n.settings.size.width[n.LEV--]||i,o=n.settings.size.height[n.LEV]||n.settings.size.height[n.LEV++]||n.settings.size.height[n.LEV--]||0,r=n.settings.size.minHeight[n.LEV]||n.settings.size.minHeight[n.LEV++]||n.settings.size.minHeight[n.LEV--]||0;if(o="auto"==o?0:o,o=parseInt(o),"carousel"!==e.type&&(i-=parseInt(e.onw??0)||0),n.MP=!n.settings.size.fullWidth&&i<l||_tpt.winW<l?Math.min(1,i/l):1,e.size.fullScreen||e.size.fullHeight){let t=parseInt(e.fho)||0,s=(""+e.fho).indexOf("%")>-1;e.newh=_tpt.winH-(s?_tpt.winH*t/100:t)}else e.newh=n.MP*Math.max(o,r);if(e.newh+=(parseInt(e.onh??0)||0)+(parseInt(e.carousel?.pt)||0)+(parseInt(e.carousel?.pb)||0),void 0!==e.slideduration&&(e.newh=Math.max(e.newh,parseInt(e.slideduration)/3)),e.shdw&&_tpt.buildShadow(e.id,e),n.c.adjuster.style.height=e.newh+"px",n.c.module.style.height=e.newh+"px",n.c.content.style.height=e.newh+"px",n.states.heightPrepared=!0,n.dims??={},n.dims.moduleRect=n.c.module.getBoundingClientRect(),n.c.content.style.left="-"+n.dims.moduleRect.left+"px",!n.settings.size.fullWidth)return s&&requestAnimationFrame((()=>{i!==n.c.module.parentNode.offsetWidth&&_tpt.updatePMHeight(e.id,e)})),void _tpt.bgStyle(e.id,e,window.innerWidth==_tpt.winW,!0);_tpt.bgStyle(e.id,e,window.innerWidth==_tpt.winW,!0),requestAnimationFrame((function(){s&&requestAnimationFrame((()=>{i!==n.c.module.parentNode.offsetWidth&&_tpt.updatePMHeight(e.id,e)}))})),n.earlyResizerFunction||(n.earlyResizerFunction=function(){requestAnimationFrame((function(){_tpt.getWinDim(),_tpt.moduleDefaults(e.id,e),_tpt.updateSlideBg(t,!0)}))},window.addEventListener("resize",n.earlyResizerFunction))},_tpt.buildShadow=function(t,e){let s=SR7.M[t];null==s.c.shadow&&(s.c.shadow=document.createElement("sr7-module-shadow"),s.c.shadow.classList.add("sr7-shdw-"+e.shdw),s.c.content.appendChild(s.c.shadow))},_tpt.bgStyle=async(t,e,s,n,i)=>{const l=SR7.M[t];if((e=e??l.settings).fixed&&!l.c.module.classList.contains("sr7-top-fixed")&&(l.c.module.classList.add("sr7-top-fixed"),l.c.module.style.position="fixed",l.c.module.style.width="100%",l.c.module.style.top="0px",l.c.module.style.left="0px",l.c.module.style.pointerEvents="none",l.c.module.style.zIndex=5e3,l.c.content.style.pointerEvents="none"),null==l.c.bgcanvas){let t=document.createElement("sr7-module-bg"),o=!1;if("string"==typeof e?.bg?.color&&e?.bg?.color.includes("{"))if(_tpt.gradient&&_tpt.gsap)e.bg.color=_tpt.gradient.convert(e.bg.color);else try{let t=JSON.parse(e.bg.color);(t?.orig||t?.string)&&(e.bg.color=JSON.parse(e.bg.color))}catch(t){return}let r="string"==typeof e?.bg?.color?e?.bg?.color||"transparent":e?.bg?.color?.string??e?.bg?.color?.orig??e?.bg?.color?.color??"transparent";if(t.style["background"+(String(r).includes("grad")?"":"Color")]=r,("transparent"!==r||i)&&(o=!0),l.offsetPrepared&&(t.style.visibility="hidden"),e?.bg?.image?.src&&(t.style.backgroundImage=`url(${e?.bg?.image.src})`,t.style.backgroundSize=""==(e.bg.image?.size??"")?"cover":e.bg.image.size,t.style.backgroundPosition=e.bg.image.position,t.style.backgroundRepeat=""==e.bg.image.repeat||null==e.bg.image.repeat?"no-repeat":e.bg.image.repeat,o=!0),!o)return;l.c.bgcanvas=t,e.size.fullWidth?t.style.width=_tpt.winW-(s&&_tpt.winH<document.body.offsetHeight?_tpt.scrollBarW:0)+"px":n&&(t.style.width=l.c.module.offsetWidth+"px"),e.sbt?.use?l.c.content.appendChild(l.c.bgcanvas):l.c.module.appendChild(l.c.bgcanvas)}l.c.bgcanvas.style.height=void 0!==e.newh?e.newh+"px":("carousel"==e.type?l.dims.module.h:l.dims.content.h)+"px",l.c.bgcanvas.style.left=!s&&e.sbt?.use||l.c.bgcanvas.closest("SR7-CONTENT")?"0px":"-"+(l?.dims?.moduleRect?.left??0)+"px"},_tpt.updateSlideBg=function(t,e){const s=SR7.M[t];let n=s.settings;s?.c?.bgcanvas&&(n.size.fullWidth?s.c.bgcanvas.style.width=_tpt.winW-(e&&_tpt.winH<document.body.offsetHeight?_tpt.scrollBarW:0)+"px":preparing&&(s.c.bgcanvas.style.width=s.c.module.offsetWidth+"px"))},_tpt.moduleDefaults=(t,e)=>{let s=SR7.M[t];null!=s&&null!=s.c&&null!=s.c.module&&(s.dims??={},s.dims.moduleRect=s.c.module.getBoundingClientRect(),s.c.content.style.left="-"+s.dims.moduleRect.left+"px",s.c.content.style.width=_tpt.winW-_tpt.scrollBarW+"px","carousel"==e.type&&(s.c.module.style.overflow="visible"),_tpt.bgStyle(t,e,window.innerWidth==_tpt.winW))},_tpt.getOffset=t=>{var e=t.getBoundingClientRect(),s=window.pageXOffset||document.documentElement.scrollLeft,n=window.pageYOffset||document.documentElement.scrollTop;return{top:e.top+n,left:e.left+s}},_tpt.fillArray=function(t,e){let s,n;t=Array.isArray(t)?t:[t];let i=Array(e),l=t.length;for(n=0;n<t.length;n++)i[n+(e-l)]=t[n],null==s&&"#"!==t[n]&&(s=t[n]);for(let t=0;t<e;t++)void 0!==i[t]&&"#"!=i[t]||(i[t]=s),s=i[t];return i},_tpt.closestGE=function(t,e){let s=Number.MAX_VALUE,n=-1;for(let i=0;i<t.length;i++)t[i]-1>=e&&t[i]-1-e<s&&(s=t[i]-1-e,n=i);return++n}}();</script>
		<style id="wp-custom-css">
			.timelinsec .twae-content{
	border-radius: 0 !important;
}
.pum-theme-2638 .pum-content + .pum-close, .pum-theme-enterprise-blue .pum-content + .pum-close{
	background: #D31B34 !important;
}
@media(max-width: 1750px){
	.headsection{
		background-image: linear-gradient(110deg, #0B0D26 33%, #FFFFFF 33%) !important;
	}
}
@media(max-width: 1550px){
	.headsection{
		background-image: linear-gradient(110deg, #0B0D26 34%, #FFFFFF 34%) !important;
		padding: 0 100px !important;
	}
}
@media(max-width: 1392px){
	.headsection{
		padding: 0 25px !important;
	}
}
@media(max-width: 1368px){
	.headsection{
		background-image: linear-gradient(110deg, #0B0D26 32%, #FFFFFF 32%) !important;
	}
}
@media(max-width: 1024px){
	.headsection{
		background-image: linear-gradient(110deg, #0B0D26 38%, #FFFFFF 38%) !important;
	}
	.sr7-leftarrow{
		transform: translate(-60px, 5px) !important;
	}
	.sr7-rightarrow{
		transform: translate(-60px, -65px) !important;
	}
	.headsection {
        padding: 0 10px !important;
    }
}
@media(max-width: 820px){
	.headsection{
		background-image: linear-gradient(110deg, #0B0D26 43%, #FFFFFF 43%) !important;
	}
}
@media(max-width: 580px){
	.headsection{
		background-image: linear-gradient(110deg, #0B0D26 55%, #FFFFFF 20%) !important;
	}
	.sr7-leftarrow{
		transform: translate(-10px, -5px) !important;
		width: 40px !important;
		height: 40px !important;
	}
	.sr7-rightarrow{
		transform: translate(-10px, -55px) !important;
		width: 40px !important;
		height: 40px !important;
	}
	.sr7-leftarrow::before,
	.sr7-rightarrow::before{
		font-size: 14px !important;
		line-height: 40px !important;
	}


	.prodycttabs1 .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title{
		display: block !important;
		width: 100% !important;
	}
	.prodycttabs1 .elementor-tabs-wrapper{
		display: block !important;
		padding: 0 0 20px 0 !important;
	}
 
}
.divsection .uc_content_box_zoom_effect .uc_content_box_zoom_effect_content{
  margin: 20px !important;
  text-align: left !important;
  margin-top: -50px !important;
  clip-path: polygon(0% 0%, 220% 0%, 70% 100%, 0% 100%) !important;	
}
.divsection .uc_content_box_zoom_effect .uc_content_box_zoom_effect_content:hover{
	background: #D31B34 !important;
}
.divsection .uc_content_box_zoom_effect:hover .uc_content_box_zoom_effect_content{
	background: #D31B34 !important;
}
.divsection .uc_content_box_zoom_effect:hover .uc_content_box_zoom_effect_content .uc_title{
	color: white !important;
}
.divsection .uc_content_box_zoom_effect:hover .uc_content_box_zoom_effect_content .uc_content p{
	color: white !important;
}
.divsection,
.divsection .elementor-widget-container,
.divsection .uc_content_box_zoom_effect,
.divsection .uc_content_box_zoom_effect_content {
	height: 100% !important;
}

.divsection .uc_content_box_zoom_effect_content {
	    display: grid;
}
.divsection .uc_content_box_zoom_effect .uc_more{
	margin: auto !important;
}

.prodycttabs1 .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title:hover{
	background: #D31B34 !important;
	color: white !important;
}
.prodycttabs .elementor-tab-content{
	padding: 0px !important;
	padding-top: 20px !important;
}
.imageslider .swiper-slide-inner img{
	filter: brightness(100%) contrast(100%) saturate(0%) blur(0px) hue-rotate(0deg) !important;
}
.imageslider .swiper-slide-inner:hover img{
	filter: brightness(100%) contrast(100%) saturate(100%) blur(0px) hue-rotate(0deg) !important;
}
.imgscales,
.imgscales .elementor-widget-container,
.imgscales .elementor-widget-container img{
	height: 100% !important;
}	
.timesec ul li.elementor-repeater-item-a44e519{
	font-family: "Exo", Sans-serif !important;
  font-size: 30px !important;
  font-weight: 700 !important;
  line-height: 30px !important;
}
.featuresImg .elementor-widget-container a{
	width: 100% !important;
}
.imgsection,
.imgsection .elementor-column-gap-default,
.imgsection .elementor-column-gap-default .elementor-column,
.imgsection .elementor-column-gap-default .elementor-column .elementor-element-populated,
.imgsection .elementor-column-gap-default .elementor-column .elementor-element-populated .featuresImg,
.imgsection .elementor-column-gap-default .elementor-column .elementor-element-populated .featuresImg .elementor-widget-container,
.imgsection .elementor-column-gap-default .elementor-column .elementor-element-populated .featuresImg .elementor-widget-container a,
.imgsection .elementor-column-gap-default .elementor-column .elementor-element-populated .featuresImg .elementor-widget-container a img{
	height: 100% !important;
}


/* clicktap start */

 

.ze-testimonail-slider .elementor-swiper .swiper-slide .elementor-testimonial .elementor-testimonial__footer {
    display: flex;
    flex-direction: column-reverse;
    !i;!;
    margin-right: 0;
    align-items: flex-start;
}

.ze-testimonail-slider .elementor-swiper .swiper-slide .elementor-testimonial .elementor-testimonial__footer cite.elementor-testimonial__cite {
    margin: 0;
}
 
.ze-testimonail-slider .elementor-swiper .swiper-slide .elementor-testimonial .elementor-testimonial__footer .elementor-testimonial__image {
    width: 100%;
}

.ze-testimonail-slider .elementor-swiper .swiper-slide .elementor-testimonial .elementor-testimonial__footer .elementor-testimonial__image img {
    width: 98px;
    object-fit: none;
    text-align: left;
    margin: 0;
}
.ze-aboutpage-tabs .elementor-tabs-wrapper {
    gap: 20px;
}

.ze-aboutpage-tabs .elementor-tabs-wrapper .elementor-tab-title {
    text-align: center;
    background-color: white;
}

.ze-aboutpage-tabs .elementor-tabs-wrapper .elementor-tab-title.elementor-active {
    background-color: black;
}
.ze-aboutpage-tabs .elementor-tabs-content-wrapper .elementor-tab-content {
    padding: 0;
}

.ze-blogs-grid article .elementor-post__text a.elementor-post__read-more {
    display: table;
    padding: 20px 30px;
    background-color: #CE0E2D;
}


/* .prodycttabs1 #elementor-tab-title-3511,
.prodycttabs1 #elementor-tab-title-3512,
.prodycttabs1 #elementor-tab-title-3513{
	background: #fff !important;
	text-align: center !important;
	box-shadow: 0px 6px 30px 0px rgba(0, 0, 0, 0.050980392156862744) !important;
	margin: 25px !important;
}
.prodycttabs1 #elementor-tab-title-3511.elementor-active,
.prodycttabs1 #elementor-tab-title-3512.elementor-active,
.prodycttabs1 #elementor-tab-title-3513.elementor-active{
	background: #0B0D26 !important;
}
.prodycttabs1 #elementor-tab-title-3511:hover,
.prodycttabs1 #elementor-tab-title-3512:hover,
.prodycttabs1 #elementor-tab-title-3513:hover{
	background: #0B0D26 !important;
	color: white !important;
	box-shadow: 0px 6px 30px 0px rgba(0, 0, 0, 0.050980392156862744) !important;
}
.prodycttabs1 .elementor-tab-content{
	padding: 0px !important;
	padding-top: 20px !important;
} */







/* .prodycttabs1 #elementor-tab-title-4031,
.prodycttabs1 #elementor-tab-title-4032,
.prodycttabs1 #elementor-tab-title-4033,
.prodycttabs1 #elementor-tab-title-4034{
	background: #fff !important;
	text-align: center !important;
	box-shadow: 0px 6px 30px 0px rgba(0, 0, 0, 0.050980392156862744) !important;
	margin: 25px !important;
	align-content: center !important;
}
.prodycttabs1 #elementor-tab-title-4031.elementor-active,
.prodycttabs1 #elementor-tab-title-4032.elementor-active,
.prodycttabs1 #elementor-tab-title-4033.elementor-active,
.prodycttabs1 #elementor-tab-title-4034.elementor-active{
	background: #0B0D26 !important;
}

.elementor-1276 .elementor-element.elementor-element-2670d47 .elementor-tab-title{
	background: #0B0D26 !important;
	color: white !important;
	box-shadow: 0px 6px 30px 0px rgba(0, 0, 0, 0.050980392156862744) !important;
} */

.prodycttabs .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title {
    background-color: #ffffff !important;!i;!;
    text-align: center;
    color: #000033;
}


.prodycttabs .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title:nth-child(1) {
    background-color: #cccccc !important;!i;!;
}

.prodycttabs .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title:nth-child(3) {
    background-color: #eeeeee !important;!i;!;
}

.prodycttabs .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title:nth-child(4) {
    background-color: #f8f8f8 !important;!I;!;
}

.prodycttabs .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title:nth-child(2) {
    background-color: #e5e5e5 !important;
}
.prodycttabs .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title.elementor-active {
    background-color: #cc3333 !important;!i;!;
}

.prodycttabs1 .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title {
    background: #fff !important;
    text-align: center !important;
    box-shadow: 0px 6px 30px 0px rgba(0, 0, 0, 0.050980392156862744) !important;
    margin: 25px !important;
    align-content: center !important;
}
.prodycttabs1 .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title.elementor-active {
    background: #0B0D26 !important;
}

.prodycttabs1 .elementor-tab-content{
	padding: 0px !important;
	padding-top: 20px !important;
}




 
.location-ser-slider .elementor-image-carousel .swiper-slide {
    padding: 20px;
}
 
.location-ser-slider .elementor-image-carousel .swiper-slide figcaption h6 {
    color: #CE0E2D;
    font-size: 14px;
    font-family: "Frutiger LT Arabic Bold", Sans-serif;
}

.location-ser-slider .elementor-image-carousel .swiper-slide figcaption h2 {
    color: #0B0D26;
    font-family: "Frutiger LT Arabic Bold", Sans-serif;
    font-size: 30px;
    font-weight: 700;
    line-height: 35px;
}

.location-ser-slider .elementor-image-carousel .swiper-slide figcaption p {
    color: #4D5765;
    font-family: "Frutiger LT Arabic", Sans-serif;
    font-size: 16px;
    font-weight: 400;
    line-height: 26px;
}

.chaty-i-trigger .chaty-channel,
.chaty-i-trigger .chaty-channel .chaty-link,
.chaty-i-trigger .chaty-channel .chaty-link .chaty-icon,
.chaty-i-trigger .chaty-channel .chaty-link .chaty-icon .chaty-svg,
.chaty-i-trigger .chaty-channel .chaty-link .chaty-icon .chaty-svg img{
	border-radius: 0px !important;
	box-shadow: none !important;
}





.poscol .elementor-element.elementor-element-b8a1223,
.poscol .elementor-element.elementor-element-b8a1223 .elementor-widget-container{
	height: 100% !important;
}


.customform form input[type="submit"] {
  color: white !important;
	background: #CE0E2D !important;
	border: none !important;
	border-radius: 50px !important;
	width: 100% !important;
	font-family: "Frutiger LT Arabic", Sans-serif !important;
	font-weight: 700 !important;
	font-size: 18px !important;
	line-height: 40px !important;
}
.customform form input::placeholder{
  color: #CBCBCB !important;
	font-weight: 500 !important;
}
.customform form textarea[name="Message"]::placeholder{
  color: #CBCBCB !important;
	font-weight: 500 !important;
}
.customform form label{
	font-family: "Frutiger LT Arabic ", Sans-serif !important;
	font-weight: 500 !important;
	font-size: 16px !important;
	line-height: 40px !important;
}
.customform form input,
.customform form textarea{
	border: 1px solid black !important;
	border-radius: 4px !important;
	font-family: "Frutiger LT Arabic ", Sans-serif !important;
	font-weight: 500 !important;
	font-size: 16px !important;
	line-height: 26px !important;
	color: black !important;
}
.customform form textarea{
	height: calc(1.5em * 4 + 20px);
}
.customform form p{
	margin-bottom: 5px !important;
}
.customform form .wpcf7-spinner{
	display: none !important;
}
.customform form .wpcf7-response-output{
	margin: 0px !important;
	text-align: center !important;
	padding: 0px !important;
	    font-family: "Frutiger LT Arabic ", Sans-serif !important;
    font-size: 14px !important;
}
.intl-tel-input .selected-flag .iti-arrow{
	right: 5px !important;
}
.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-4 .selected-flag{
	width: 100px !important
}
.customform form input.form-field-phone,
.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-5 input,
.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-4 input{
	padding-left: 110px !important;
}
.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-4 .selected-flag,
.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-5 .selected-flag{
    width: 100px !important;
}







.aboutslider .slick-arrow{
  margin-top: -25px !important;
	width: 30px !important;
  height: 30px !important;
	border: 2px solid #fff !important;
}
.aboutslider .slick-arrow:hover{
  border: 2px solid #fff !important;
}
.aboutslider .slick-arrow svg{
	height: 15px !important;
  width: 15px !important;
	fill: #fff !important;
}
.wpostahs-slider-design-2 .wpostahs-slider-nav .slick-current .wpostahs-main-title button{
  border-color: #fff !important;
  background: #CE0E2D !important;
}
.wpostahs-slider-design-2 .wpostahs-slider-nav .wpostahs-slider-nav-title:hover .wpostahs-main-title button {
  border-color: #fff !important;
  background: #CE0E2D !important;
  transition: all 0.5s ease-in-out;
}
.wpostahs-slider-design-2 .wpostahs-slider-nav .slick-current{
	color: #CE0E2D !important;
	font-family: "Outfit", Sans-serif !important;
  font-weight: 700 !important;
}
.wpostahs-centent-title{
	display: none !important;
}
.wpostahs-centent p{
	color: #FFFFFF !important;
  font-family: "Frutiger LT Arabic", Sans-serif !important;
  font-size: 16px !important;
  line-height: 26px !important;
}
ul.slick-dots{
	display: none !important;
}


.ze-info-box-container .elementor-container .elementor-column .ze-info-box .elementor-widget-container {
    height: 100% !important;
}
.ze-info-box-container .ze-info-box {
    height: 100% !important;
}


@media(max-width: 1300px){
/* 	.prodycttabs1 #elementor-tab-title-3511,
.prodycttabs1 #elementor-tab-title-3512,
	.prodycttabs1 #elementor-tab-title-3513{
		margin: 15px !important;
	}
	.prodycttabs1 #elementor-tab-title-4031,
.prodycttabs1 #elementor-tab-title-4032,
	.prodycttabs1 #elementor-tab-title-4033,
	.prodycttabs1 #elementor-tab-title-4034{
		margin: 15px !important;
	} */
	.prodycttabs1 .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title {
    margin: 15px !important;
}
}
@media(max-width: 1024px){
.prodycttabs1 .elementor-tabs .elementor-tabs-wrapper {
    display: flex;
    flex-wrap: wrap;
	}
	.prodycttabs .elementor-tabs .elementor-tabs-wrapper {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}
}
@media(max-width: 524px){
/* 	.prodycttabs1 #elementor-tab-title-3511,
.prodycttabs1 #elementor-tab-title-3512,
	.prodycttabs1 #elementor-tab-title-3513{
		margin: 0px !important;
		margin-top: 15px !important;
	}
	.prodycttabs1 #elementor-tab-title-4031,
.prodycttabs1 #elementor-tab-title-4032,
	.prodycttabs1 #elementor-tab-title-4033,
	.prodycttabs1 #elementor-tab-title-4034{
		margin: 0px !important;
		margin-top: 15px !important;
	} */
}













		</style>
		</head>
<body class="error404 elementor-default elementor-kit-6">


<a class="skip-link screen-reader-text" href="#content">Skip to content</a>

		<div data-elementor-type="header" data-elementor-id="9" class="elementor elementor-9 elementor-location-header" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-e615d86 elementor-section-full_width elementor-hidden-tablet elementor-hidden-mobile elementor-section-height-default elementor-section-height-default" data-id="e615d86" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-846d5b3" data-id="846d5b3" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-4f96a94 elementor-icon-list--layout-inline elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="4f96a94" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<a href="tel:+966%2055%20507%202159">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none"><path d="M15 11C15.375 11.1667 15.6458 11.4271 15.8125 11.7812C15.9792 12.1146 16.0208 12.4792 15.9375 12.875L15.2812 15.7188C15.1979 16.1146 15.0104 16.4271 14.7188 16.6562C14.4271 16.8854 14.0938 17 13.7188 17C11.1562 16.9792 8.84375 16.3542 6.78125 15.125C4.73958 13.8958 3.10417 12.2604 1.875 10.2188C0.645833 8.15625 0.0208333 5.84375 0 3.28125C0 2.90625 0.114583 2.57292 0.34375 2.28125C0.572917 1.98958 0.885417 1.79167 1.28125 1.6875L4.125 1.03125C4.52083 0.947917 4.88542 1 5.21875 1.1875C5.57292 1.35417 5.83333 1.625 6 2L7.3125 5.09375C7.45833 5.42708 7.48958 5.77083 7.40625 6.125C7.32292 6.47917 7.13542 6.77083 6.84375 7L5.78125 7.875C6.61458 9.27083 7.73958 10.3854 9.15625 11.2188L10.0312 10.1562C10.2604 9.86458 10.5521 9.67708 10.9062 9.59375C11.2604 9.51042 11.6042 9.54167 11.9375 9.6875L15 11ZM14.5 12.5312C14.5 12.4688 14.4688 12.4062 14.4062 12.3438L11.3438 11.0312C11.2812 11.0104 11.2292 11.0312 11.1875 11.0938L9.9375 12.5938C9.66667 12.8854 9.36458 12.9583 9.03125 12.8125C7.96875 12.2917 7.02083 11.6146 6.1875 10.7812C5.375 9.94792 4.69792 9 4.15625 7.9375C4.01042 7.58333 4.08333 7.28125 4.375 7.03125L5.90625 5.8125C5.94792 5.77083 5.95833 5.71875 5.9375 5.65625L4.625 2.59375C4.58333 2.53125 4.54167 2.5 4.5 2.5C4.47917 2.5 4.46875 2.5 4.46875 2.5L1.59375 3.15625C1.53125 3.17708 1.5 3.21875 1.5 3.28125C1.52083 5.55208 2.07292 7.60417 3.15625 9.4375C4.26042 11.2708 5.72917 12.7396 7.5625 13.8438C9.39583 14.9271 11.4479 15.4792 13.7188 15.5C13.7812 15.4792 13.8229 15.4479 13.8438 15.4062L14.5 12.5312Z" fill="white"></path></svg>						</span>
										<span class="elementor-icon-list-text">+966 55 507 2159</span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="12" height="16" viewBox="0 0 12 16" fill="none"><path d="M8.5 6C8.47917 6.70833 8.23958 7.30208 7.78125 7.78125C7.30208 8.23958 6.70833 8.47917 6 8.5C5.29167 8.47917 4.69792 8.23958 4.21875 7.78125C3.76042 7.30208 3.52083 6.70833 3.5 6C3.52083 5.29167 3.76042 4.69792 4.21875 4.21875C4.69792 3.76042 5.29167 3.52083 6 3.5C6.70833 3.52083 7.30208 3.76042 7.78125 4.21875C8.23958 4.69792 8.47917 5.29167 8.5 6ZM6 5C5.70833 5 5.46875 5.09375 5.28125 5.28125C5.09375 5.46875 5 5.70833 5 6C5 6.29167 5.09375 6.53125 5.28125 6.71875C5.46875 6.90625 5.70833 7 6 7C6.29167 7 6.53125 6.90625 6.71875 6.71875C6.90625 6.53125 7 6.29167 7 6C7 5.70833 6.90625 5.46875 6.71875 5.28125C6.53125 5.09375 6.29167 5 6 5ZM12 6C11.9583 6.9375 11.625 8.02083 11 9.25C10.3542 10.4792 9.625 11.6667 8.8125 12.8125C8 13.9792 7.3125 14.9062 6.75 15.5938C6.54167 15.8438 6.29167 15.9688 6 15.9688C5.70833 15.9688 5.45833 15.8438 5.25 15.5938C4.6875 14.9062 3.98958 13.9792 3.15625 12.8125C2.34375 11.6667 1.625 10.4792 1 9.25C0.375 8.02083 0.0416667 6.9375 0 6C0.0416667 4.29167 0.625 2.875 1.75 1.75C2.875 0.625 4.29167 0.0416667 6 0C7.70833 0.0416667 9.125 0.625 10.25 1.75C11.375 2.875 11.9583 4.29167 12 6ZM6 1.5C4.72917 1.54167 3.66667 1.97917 2.8125 2.8125C1.97917 3.66667 1.54167 4.72917 1.5 6C1.5 6.39583 1.65625 6.98958 1.96875 7.78125C2.32292 8.57292 2.77083 9.40625 3.3125 10.2812C3.75 11.0104 4.20833 11.6979 4.6875 12.3438C5.16667 13.0104 5.60417 13.6042 6 14.125C6.39583 13.6042 6.83333 13.0208 7.3125 12.375C7.79167 11.7083 8.25 11.0104 8.6875 10.2812C9.22917 9.40625 9.67708 8.57292 10.0312 7.78125C10.3438 6.98958 10.5 6.39583 10.5 6C10.4583 4.72917 10.0208 3.66667 9.1875 2.8125C8.33333 1.97917 7.27083 1.54167 6 1.5Z" fill="white"></path></svg>						</span>
										<span class="elementor-icon-list-text">11 St, First Industrial Area, Dammam 31431, Saudi Arabia</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="mailto:sales@salamaeng.com">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" viewBox="0 0 16 12" fill="none"><path d="M0 2C0.0208333 1.4375 0.21875 0.96875 0.59375 0.59375C0.96875 0.21875 1.4375 0.0208333 2 0H14C14.5625 0.0208333 15.0312 0.21875 15.4062 0.59375C15.7812 0.96875 15.9792 1.4375 16 2V10C15.9792 10.5625 15.7812 11.0312 15.4062 11.4062C15.0312 11.7812 14.5625 11.9792 14 12H2C1.4375 11.9792 0.96875 11.7812 0.59375 11.4062C0.21875 11.0312 0.0208333 10.5625 0 10V2ZM1.5 2V2.6875L6.90625 7.125C7.23958 7.375 7.60417 7.5 8 7.5C8.39583 7.5 8.77083 7.375 9.125 7.125L14.5 2.6875V1.96875C14.4792 1.67708 14.3125 1.51042 14 1.46875H2C1.6875 1.51042 1.52083 1.67708 1.5 1.96875V2ZM1.5 4.625V10C1.52083 10.3125 1.6875 10.4792 2 10.5H14C14.3125 10.4792 14.4792 10.3125 14.5 10V4.625L10.0625 8.28125C9.4375 8.76042 8.75 9 8 9C7.25 9 6.55208 8.76042 5.90625 8.28125L1.5 4.625Z" fill="white"></path></svg>						</span>
										<span class="elementor-icon-list-text">sales@salamaeng.com</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-551b315" data-id="551b315" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f8c6582 elementor-shape-square e-grid-align-right elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="f8c6582" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook-f elementor-repeater-item-b966fbd" href="https://www.facebook.com/salamaengineering" target="_blank">
						<span class="elementor-screen-only">Facebook-f</span>
						<svg class="e-font-icon-svg e-fab-facebook-f" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg"><path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-x-twitter elementor-repeater-item-a3e9338" href="https://twitter.com/SEngIndustries" target="_blank">
						<span class="elementor-screen-only">X-twitter</span>
						<svg class="e-font-icon-svg e-fab-x-twitter" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin-in elementor-repeater-item-d9717b8" href="https://www.linkedin.com/company/salama-engineering-industries/" target="_blank">
						<span class="elementor-screen-only">Linkedin-in</span>
						<svg class="e-font-icon-svg e-fab-linkedin-in" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-475be43" href="https://www.instagram.com/salama.engineering/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<svg class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg>					</a>
				</span>
					</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-211a95b elementor-section-full_width headsection elementor-section-height-default elementor-section-height-default" data-id="211a95b" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-29f9c00" data-id="29f9c00" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-08054eb elementor-widget elementor-widget-image" data-id="08054eb" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
														<a href="https://salamaeng.com/">
							<img fetchpriority="high" width="536" height="148" src="https://salamaeng.com/wp-content/uploads/2024/09/header-logo-1.svg" class="attachment-full size-full wp-image-2656" alt="" />								</a>
													</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7cb9eaf" data-id="7cb9eaf" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-fd3f16d elementor-nav-menu--stretch elementor-widget__width-auto elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="fd3f16d" data-element_type="widget" data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;svg class=\&quot;e-font-icon-svg e-fas-caret-down\&quot; viewBox=\&quot;0 0 320 512\&quot; xmlns=\&quot;http:\/\/www.w3.org\/2000\/svg\&quot;&gt;&lt;path d=\&quot;M31.3 192h257.3c17.8 0 26.7 21.5 14.1 34.1L174.1 354.8c-7.8 7.8-20.5 7.8-28.3 0L17.2 226.1C4.6 213.5 13.5 192 31.3 192z\&quot;&gt;&lt;\/path&gt;&lt;\/svg&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;},&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav aria-label="Menu" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-underline e--animation-fade">
				<ul id="menu-1-fd3f16d" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-18"><a href="https://salamaeng.com/" class="elementor-item">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-701"><a href="https://salamaeng.com/about-us/" class="elementor-item">About Company</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1091"><a href="https://salamaeng.com/divisions/" class="elementor-item">Divisions</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1092"><a href="https://salamaeng.com/our-products/" class="elementor-item">Products</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1350"><a href="https://salamaeng.com/capabilities/" class="elementor-item">Capabilities</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1093"><a href="https://salamaeng.com/clientele/" class="elementor-item">Clientele</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1223"><a href="https://salamaeng.com/events/" class="elementor-item">Events</a></li>
</ul>			</nav>
					<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
			<svg aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--open e-font-icon-svg e-eicon-menu-bar" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg"><path d="M104 333H896C929 333 958 304 958 271S929 208 896 208H104C71 208 42 237 42 271S71 333 104 333ZM104 583H896C929 583 958 554 958 521S929 458 896 458H104C71 458 42 487 42 521S71 583 104 583ZM104 833H896C929 833 958 804 958 771S929 708 896 708H104C71 708 42 737 42 771S71 833 104 833Z"></path></svg><svg aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--close e-font-icon-svg e-eicon-close" viewBox="0 0 1000 1000" xmlns="http://www.w3.org/2000/svg"><path d="M742 167L500 408 258 167C246 154 233 150 217 150 196 150 179 158 167 167 154 179 150 196 150 212 150 229 154 242 171 254L408 500 167 742C138 771 138 800 167 829 196 858 225 858 254 829L496 587 738 829C750 842 767 846 783 846 800 846 817 842 829 829 842 817 846 804 846 783 846 767 842 750 829 737L588 500 833 258C863 229 863 200 833 171 804 137 775 137 742 167Z"></path></svg>			<span class="elementor-screen-only">Menu</span>
		</div>
					<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true">
				<ul id="menu-2-fd3f16d" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-18"><a href="https://salamaeng.com/" class="elementor-item" tabindex="-1">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-701"><a href="https://salamaeng.com/about-us/" class="elementor-item" tabindex="-1">About Company</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1091"><a href="https://salamaeng.com/divisions/" class="elementor-item" tabindex="-1">Divisions</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1092"><a href="https://salamaeng.com/our-products/" class="elementor-item" tabindex="-1">Products</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1350"><a href="https://salamaeng.com/capabilities/" class="elementor-item" tabindex="-1">Capabilities</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1093"><a href="https://salamaeng.com/clientele/" class="elementor-item" tabindex="-1">Clientele</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1223"><a href="https://salamaeng.com/events/" class="elementor-item" tabindex="-1">Events</a></li>
</ul>			</nav>
				</div>
				</div>
				<div class="elementor-element elementor-element-aba7ba4 elementor-widget__width-auto elementor-hidden-mobile elementor-hidden-desktop elementor-hidden-tablet elementor-view-default elementor-widget elementor-widget-icon" data-id="aba7ba4" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<a class="elementor-icon" href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE1MDEiLCJ0b2dnbGUiOmZhbHNlfQ%3D%3D">
			<svg xmlns="http://www.w3.org/2000/svg" width="47" height="46" viewBox="0 0 47 46" fill="none"><circle cx="23.5" cy="23" r="22" stroke="#E4E4E4" stroke-width="2"></circle><path d="M31.25 29.7188C31.5625 30.0729 31.5729 30.4271 31.2812 30.7812C31.1354 30.9271 30.9583 31 30.75 31C30.5625 31 30.375 30.9271 30.1875 30.7812L26 26.5938C24.875 27.5104 23.5312 27.9792 21.9688 28C20.1354 27.9583 18.6146 27.3229 17.4062 26.0938C16.1771 24.8646 15.5417 23.3333 15.5 21.5C15.5417 19.6667 16.1667 18.1354 17.375 16.9062C18.6042 15.6771 20.1354 15.0417 21.9688 15C23.8021 15.0417 25.3333 15.6771 26.5625 16.9062C27.7917 18.1354 28.4271 19.6667 28.4688 21.5C28.4479 23.0417 27.9792 24.3854 27.0625 25.5312L31.25 29.7188ZM17 21.5C17.0417 22.9167 17.5312 24.0938 18.4688 25.0312C19.4062 25.9688 20.5833 26.4583 22 26.5C23.4167 26.4583 24.5938 25.9688 25.5312 25.0312C26.4688 24.0938 26.9583 22.9167 27 21.5C26.9583 20.0833 26.4688 18.9062 25.5312 17.9688C24.5938 17.0312 23.4167 16.5417 22 16.5C20.5833 16.5417 19.4062 17.0312 18.4688 17.9688C17.5312 18.9062 17.0417 20.0833 17 21.5Z" fill="#0E121D"></path></svg>			</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-ee0c5f4 elementor-widget__width-auto elementor-hidden-mobile elementor-widget elementor-widget-button" data-id="ee0c5f4" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://salamaeng.com/contact-us/">
						<span class="elementor-button-content-wrapper">
									<span class="elementor-button-text">Contact Us</span>
					</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		<main id="content" class="site-main">

			<div class="page-header">
			<h1 class="entry-title">The page can&rsquo;t be found.</h1>
		</div>
	
	<div class="page-content">
		<p>It looks like nothing was found at this location.</p>
	</div>

</main>
		<div data-elementor-type="footer" data-elementor-id="11" class="elementor elementor-11 elementor-location-footer" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-f41f5c1 elementor-section-full_width elementor-section-height-min-height elementor-section-height-default elementor-section-items-middle" data-id="f41f5c1" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;video&quot;,&quot;background_play_on_mobile&quot;:&quot;yes&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-85dc3ea" data-id="85dc3ea" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-6ba7c76 elementor-section-full_width elementor-section-height-min-height elementor-section-content-middle firstfold elementor-section-height-default" data-id="6ba7c76" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;video&quot;,&quot;background_video_link&quot;:&quot;https:\/\/salamaeng.com\/wp-content\/uploads\/2024\/12\/SalamaEngineering.mp4&quot;,&quot;background_play_on_mobile&quot;:&quot;yes&quot;}">
								<div class="elementor-background-video-container">
													<video class="elementor-background-video-hosted elementor-html5-video" autoplay muted playsinline loop></video>
											</div>
									<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d958934" data-id="d958934" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-551b826 elementor-widget elementor-widget-heading" data-id="551b826" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Are You Ready to Innovate With Us?</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-e1b02c9 elementor-widget elementor-widget-text-editor" data-id="e1b02c9" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Our expertise and commitment guarantee the success of your project. Experience the difference of innovative design and cutting edge solutions. Contact Now!</p>						</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-1c432fa elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="1c432fa" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-eb8336c" data-id="eb8336c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-58b92ec elementor-position-left elementor-widget__width-auto elementor-view-default elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="58b92ec" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<a href="tel:+966138471959" class="elementor-icon elementor-animation-" tabindex="-1">
				<svg xmlns="http://www.w3.org/2000/svg" width="58" height="57" viewBox="0 0 58 57" fill="none"><ellipse opacity="0.3" cx="28.9999" cy="28.5" rx="29" ry="28.5" fill="white"></ellipse><ellipse cx="29.111" cy="29" rx="21.1111" ry="20" fill="white"></ellipse><path d="M36.9647 33.8555L36.1561 37.4062C35.9921 37.9453 35.6288 38.2266 35.0663 38.25C32.0897 38.2266 29.3944 37.4883 26.9803 36.0352C24.5663 34.6055 22.6444 32.6836 21.2147 30.2695C19.7616 27.8555 19.0233 25.1602 18.9999 22.1836C19.0233 21.6211 19.3046 21.2578 19.8436 21.0938L23.3944 20.2852C23.9569 20.1914 24.3788 20.4023 24.66 20.918L26.2772 24.7148C26.4647 25.2305 26.3593 25.6641 25.9608 26.0156L24.0975 27.5273C24.6835 28.7461 25.4569 29.8359 26.4178 30.7969C27.3788 31.7578 28.4686 32.543 29.6874 33.1523L31.2343 31.2539C31.5858 30.8555 32.0194 30.75 32.535 30.9375L36.3319 32.5547C36.8241 32.8594 37.035 33.293 36.9647 33.8555Z" fill="#101130"></path></svg>				</a>
			</div>
			
						<div class="elementor-icon-box-content">

									<h3 class="elementor-icon-box-title">
						<a href="tel:+966138471959" >
							Contact						</a>
					</h3>
				
									<p class="elementor-icon-box-description">
						<a style="color:white;" href="tel:+966 55 507 2159">+966 55 507 2159</a>					</p>
				
			</div>
			
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1097362" data-id="1097362" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-4cc3af9 elementor-position-left elementor-mobile-position-left elementor-widget__width-auto elementor-view-default elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="4cc3af9" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<a href="mailto:info@salamaeng.com" class="elementor-icon elementor-animation-" tabindex="-1">
				<svg xmlns="http://www.w3.org/2000/svg" width="58" height="57" viewBox="0 0 58 57" fill="none"><ellipse opacity="0.3" cx="29" cy="28.5" rx="29" ry="28.5" fill="white"></ellipse><ellipse cx="29.1111" cy="29" rx="21.1111" ry="20" fill="white"></ellipse><path d="M35.0918 22.5C35.5605 22.5234 35.959 22.6875 36.2871 22.9922C36.5918 23.3203 36.7559 23.7188 36.7793 24.1875C36.7559 24.75 36.5332 25.1953 36.1113 25.5234L28.4473 31.2891C28.002 31.5703 27.5566 31.5703 27.1113 31.2891L19.4473 25.5234C19.0254 25.1953 18.8027 24.75 18.7793 24.1875C18.8027 23.7188 18.9668 23.3203 19.2715 22.9922C19.5996 22.6875 19.998 22.5234 20.4668 22.5H35.0918ZM26.4434 32.168C26.8418 32.4727 27.2871 32.625 27.7793 32.625C28.2715 32.625 28.7168 32.4727 29.1152 32.168L36.7793 26.4375V33.75C36.7559 34.3828 36.5332 34.9102 36.1113 35.332C35.6895 35.7539 35.1621 35.9766 34.5293 36H21.0293C20.3965 35.9766 19.8691 35.7539 19.4473 35.332C19.0254 34.9102 18.8027 34.3828 18.7793 33.75V26.4375L26.4434 32.168Z" fill="#101130"></path></svg>				</a>
			</div>
			
						<div class="elementor-icon-box-content">

									<h3 class="elementor-icon-box-title">
						<a href="mailto:info@salamaeng.com" >
							Email						</a>
					</h3>
				
									<p class="elementor-icon-box-description">
						<a style="color:white;" href="mailto:sales@salamaeng.com">sales@salamaeng.com</a>					</p>
				
			</div>
			
		</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<div class="elementor-element elementor-element-09999ef elementor-widget__width-auto elementor-widget elementor-widget-button" data-id="09999ef" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-sm" href="https://salamaeng.com/about-us/">
						<span class="elementor-button-content-wrapper">
									<span class="elementor-button-text">More About Us</span>
					</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5bbee44" data-id="5bbee44" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-3ab5f8b elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="3ab5f8b" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-7f07405" data-id="7f07405" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-7884908 elementor-widget elementor-widget-heading" data-id="7884908" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Request A Quote</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-8361cb1 elementor-button-align-stretch elementor-widget elementor-widget-form" data-id="8361cb1" data-element_type="widget" data-settings="{&quot;step_next_label&quot;:&quot;Next&quot;,&quot;step_previous_label&quot;:&quot;Previous&quot;,&quot;button_width&quot;:&quot;100&quot;,&quot;step_type&quot;:&quot;number_text&quot;,&quot;step_icon_shape&quot;:&quot;circle&quot;}" data-widget_type="form.default">
				<div class="elementor-widget-container">
					<form class="elementor-form" method="post" name="New Form">
			<input type="hidden" name="post_id" value="11"/>
			<input type="hidden" name="form_id" value="8361cb1"/>
			<input type="hidden" name="referer_title" value="Page not found" />

			
			<div class="elementor-form-fields-wrapper elementor-labels-">
								<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-name elementor-col-50">
												<label for="form-field-name" class="elementor-field-label elementor-screen-only">
								Name							</label>
														<input size="1" type="text" name="form_fields[name]" id="form-field-name" class="elementor-field elementor-size-md  elementor-field-textual" placeholder="Your name">
											</div>
								<div class="elementor-field-type-email elementor-field-group elementor-column elementor-field-group-field_e95dc94 elementor-col-50 elementor-field-required">
												<label for="form-field-field_e95dc94" class="elementor-field-label elementor-screen-only">
								Email							</label>
														<input size="1" type="email" name="form_fields[field_e95dc94]" id="form-field-field_e95dc94" class="elementor-field elementor-size-md  elementor-field-textual" placeholder="Your email" required="required" aria-required="true">
											</div>
								<div class="elementor-field-type-tel elementor-field-group elementor-column elementor-field-group-field_51c9d3c elementor-col-50">
												<label for="form-field-field_51c9d3c" class="elementor-field-label elementor-screen-only">
								Phone number							</label>
								<input size="1" type="tel" name="form_fields[field_51c9d3c]" id="form-field-field_51c9d3c" class="elementor-field elementor-size-md  elementor-field-textual" placeholder="Phone number" pattern="[0-9()#&amp;+*-=.]+" title="Only numbers and phone characters (#, -, *, etc) are accepted.">

						</div>
								<div class="elementor-field-type-select elementor-field-group elementor-column elementor-field-group-field_5bf2002 elementor-col-50">
												<label for="form-field-field_5bf2002" class="elementor-field-label elementor-screen-only">
								Select Services							</label>
								<div class="elementor-field elementor-select-wrapper remove-before ">
			<div class="select-caret-down-wrapper">
				<svg aria-hidden="true" class="e-font-icon-svg e-eicon-caret-down" viewBox="0 0 571.4 571.4" xmlns="http://www.w3.org/2000/svg"><path d="M571 393Q571 407 561 418L311 668Q300 679 286 679T261 668L11 418Q0 407 0 393T11 368 36 357H536Q550 357 561 368T571 393Z"></path></svg>			</div>
			<select name="form_fields[field_5bf2002]" id="form-field-field_5bf2002" class="elementor-field-textual elementor-size-md">
									<option value="Select Division">Select Division</option>
									<option value=" Process Equipment ">Process Equipment  </option>
									<option value=" HAVC - R Coils">HAVC - R Coils </option>
									<option value=" Plate Heat Exchangers">Plate Heat Exchangers </option>
							</select>
		</div>
						</div>
								<div class="elementor-field-type-textarea elementor-field-group elementor-column elementor-field-group-message elementor-col-100">
												<label for="form-field-message" class="elementor-field-label elementor-screen-only">
								Message							</label>
						<textarea class="elementor-field-textual elementor-field  elementor-size-md" name="form_fields[message]" id="form-field-message" rows="4" placeholder="Message"></textarea>				</div>
								<div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100 e-form__buttons">
					<button class="elementor-button elementor-size-md" type="submit">
						<span class="elementor-button-content-wrapper">
																						<span class="elementor-button-text">Send Message</span>
													</span>
					</button>
				</div>
			</div>
		</form>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-e33827e elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="e33827e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-37e0602" data-id="37e0602" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-794507f elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="794507f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-bad34f1" data-id="bad34f1" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f07596b elementor-widget elementor-widget-image" data-id="f07596b" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img width="257" height="71" src="https://salamaeng.com/wp-content/uploads/2024/09/footer-logo.svg" class="attachment-full size-full wp-image-1656" alt="" />													</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-8e1b2d2" data-id="8e1b2d2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f0f6e20 elementor-widget elementor-widget-heading" data-id="f0f6e20" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Quick Links</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-41ffe23 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="41ffe23" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://salamaeng.com/">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M16.8367 8.36377L9.63669 1.16377C9.46695 0.999831 9.23961 0.909116 9.00363 0.911167C8.76765 0.913217 8.54192 1.00787 8.37505 1.17474C8.20819 1.3416 8.11353 1.56734 8.11148 1.80331C8.10943 2.03929 8.20015 2.26663 8.36409 2.43637L14.0278 8.10007H1.80039C1.5617 8.10007 1.33278 8.1949 1.16399 8.36368C0.995212 8.53246 0.900391 8.76138 0.900391 9.00007C0.900391 9.23877 0.995212 9.46769 1.16399 9.63647C1.33278 9.80525 1.5617 9.90007 1.80039 9.90007H14.0278L8.36409 15.5638C8.27813 15.6468 8.20957 15.7461 8.1624 15.8559C8.11523 15.9657 8.0904 16.0838 8.08937 16.2033C8.08833 16.3228 8.1111 16.4413 8.15635 16.5519C8.2016 16.6625 8.26843 16.763 8.35294 16.8475C8.43744 16.932 8.53793 16.9989 8.64853 17.0441C8.75914 17.0894 8.87765 17.1121 8.99715 17.1111C9.11665 17.1101 9.23475 17.0852 9.34455 17.0381C9.45436 16.9909 9.55367 16.9223 9.63669 16.8364L16.8367 9.63637C17.0054 9.4676 17.1002 9.23872 17.1002 9.00007C17.1002 8.76143 17.0054 8.53255 16.8367 8.36377Z" fill="#FF4A37"></path></svg>						</span>
										<span class="elementor-icon-list-text">Home</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://salamaeng.com/about-us/">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M16.8367 8.36377L9.63669 1.16377C9.46695 0.999831 9.23961 0.909116 9.00363 0.911167C8.76765 0.913217 8.54192 1.00787 8.37505 1.17474C8.20819 1.3416 8.11353 1.56734 8.11148 1.80331C8.10943 2.03929 8.20015 2.26663 8.36409 2.43637L14.0278 8.10007H1.80039C1.5617 8.10007 1.33278 8.1949 1.16399 8.36368C0.995212 8.53246 0.900391 8.76138 0.900391 9.00007C0.900391 9.23877 0.995212 9.46769 1.16399 9.63647C1.33278 9.80525 1.5617 9.90007 1.80039 9.90007H14.0278L8.36409 15.5638C8.27813 15.6468 8.20957 15.7461 8.1624 15.8559C8.11523 15.9657 8.0904 16.0838 8.08937 16.2033C8.08833 16.3228 8.1111 16.4413 8.15635 16.5519C8.2016 16.6625 8.26843 16.763 8.35294 16.8475C8.43744 16.932 8.53793 16.9989 8.64853 17.0441C8.75914 17.0894 8.87765 17.1121 8.99715 17.1111C9.11665 17.1101 9.23475 17.0852 9.34455 17.0381C9.45436 16.9909 9.55367 16.9223 9.63669 16.8364L16.8367 9.63637C17.0054 9.4676 17.1002 9.23872 17.1002 9.00007C17.1002 8.76143 17.0054 8.53255 16.8367 8.36377Z" fill="#FF4A37"></path></svg>						</span>
										<span class="elementor-icon-list-text">About us</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://salamaeng.com/divisions/">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M16.8367 8.36377L9.63669 1.16377C9.46695 0.999831 9.23961 0.909116 9.00363 0.911167C8.76765 0.913217 8.54192 1.00787 8.37505 1.17474C8.20819 1.3416 8.11353 1.56734 8.11148 1.80331C8.10943 2.03929 8.20015 2.26663 8.36409 2.43637L14.0278 8.10007H1.80039C1.5617 8.10007 1.33278 8.1949 1.16399 8.36368C0.995212 8.53246 0.900391 8.76138 0.900391 9.00007C0.900391 9.23877 0.995212 9.46769 1.16399 9.63647C1.33278 9.80525 1.5617 9.90007 1.80039 9.90007H14.0278L8.36409 15.5638C8.27813 15.6468 8.20957 15.7461 8.1624 15.8559C8.11523 15.9657 8.0904 16.0838 8.08937 16.2033C8.08833 16.3228 8.1111 16.4413 8.15635 16.5519C8.2016 16.6625 8.26843 16.763 8.35294 16.8475C8.43744 16.932 8.53793 16.9989 8.64853 17.0441C8.75914 17.0894 8.87765 17.1121 8.99715 17.1111C9.11665 17.1101 9.23475 17.0852 9.34455 17.0381C9.45436 16.9909 9.55367 16.9223 9.63669 16.8364L16.8367 9.63637C17.0054 9.4676 17.1002 9.23872 17.1002 9.00007C17.1002 8.76143 17.0054 8.53255 16.8367 8.36377Z" fill="#FF4A37"></path></svg>						</span>
										<span class="elementor-icon-list-text">Divisions</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-4afa6d3" data-id="4afa6d3" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-0b2f214 elementor-widget elementor-widget-heading" data-id="0b2f214" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Useful Links</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-b0e3396 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="b0e3396" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://salamaeng.com/our-products/">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M16.8367 8.36377L9.63669 1.16377C9.46695 0.999831 9.23961 0.909116 9.00363 0.911167C8.76765 0.913217 8.54192 1.00787 8.37505 1.17474C8.20819 1.3416 8.11353 1.56734 8.11148 1.80331C8.10943 2.03929 8.20015 2.26663 8.36409 2.43637L14.0278 8.10007H1.80039C1.5617 8.10007 1.33278 8.1949 1.16399 8.36368C0.995212 8.53246 0.900391 8.76138 0.900391 9.00007C0.900391 9.23877 0.995212 9.46769 1.16399 9.63647C1.33278 9.80525 1.5617 9.90007 1.80039 9.90007H14.0278L8.36409 15.5638C8.27813 15.6468 8.20957 15.7461 8.1624 15.8559C8.11523 15.9657 8.0904 16.0838 8.08937 16.2033C8.08833 16.3228 8.1111 16.4413 8.15635 16.5519C8.2016 16.6625 8.26843 16.763 8.35294 16.8475C8.43744 16.932 8.53793 16.9989 8.64853 17.0441C8.75914 17.0894 8.87765 17.1121 8.99715 17.1111C9.11665 17.1101 9.23475 17.0852 9.34455 17.0381C9.45436 16.9909 9.55367 16.9223 9.63669 16.8364L16.8367 9.63637C17.0054 9.4676 17.1002 9.23872 17.1002 9.00007C17.1002 8.76143 17.0054 8.53255 16.8367 8.36377Z" fill="#FF4A37"></path></svg>						</span>
										<span class="elementor-icon-list-text">Products</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://salamaeng.com/events/">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M16.8367 8.36377L9.63669 1.16377C9.46695 0.999831 9.23961 0.909116 9.00363 0.911167C8.76765 0.913217 8.54192 1.00787 8.37505 1.17474C8.20819 1.3416 8.11353 1.56734 8.11148 1.80331C8.10943 2.03929 8.20015 2.26663 8.36409 2.43637L14.0278 8.10007H1.80039C1.5617 8.10007 1.33278 8.1949 1.16399 8.36368C0.995212 8.53246 0.900391 8.76138 0.900391 9.00007C0.900391 9.23877 0.995212 9.46769 1.16399 9.63647C1.33278 9.80525 1.5617 9.90007 1.80039 9.90007H14.0278L8.36409 15.5638C8.27813 15.6468 8.20957 15.7461 8.1624 15.8559C8.11523 15.9657 8.0904 16.0838 8.08937 16.2033C8.08833 16.3228 8.1111 16.4413 8.15635 16.5519C8.2016 16.6625 8.26843 16.763 8.35294 16.8475C8.43744 16.932 8.53793 16.9989 8.64853 17.0441C8.75914 17.0894 8.87765 17.1121 8.99715 17.1111C9.11665 17.1101 9.23475 17.0852 9.34455 17.0381C9.45436 16.9909 9.55367 16.9223 9.63669 16.8364L16.8367 9.63637C17.0054 9.4676 17.1002 9.23872 17.1002 9.00007C17.1002 8.76143 17.0054 8.53255 16.8367 8.36377Z" fill="#FF4A37"></path></svg>						</span>
										<span class="elementor-icon-list-text">Events</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://salamaeng.com/contact-us/">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M16.8367 8.36377L9.63669 1.16377C9.46695 0.999831 9.23961 0.909116 9.00363 0.911167C8.76765 0.913217 8.54192 1.00787 8.37505 1.17474C8.20819 1.3416 8.11353 1.56734 8.11148 1.80331C8.10943 2.03929 8.20015 2.26663 8.36409 2.43637L14.0278 8.10007H1.80039C1.5617 8.10007 1.33278 8.1949 1.16399 8.36368C0.995212 8.53246 0.900391 8.76138 0.900391 9.00007C0.900391 9.23877 0.995212 9.46769 1.16399 9.63647C1.33278 9.80525 1.5617 9.90007 1.80039 9.90007H14.0278L8.36409 15.5638C8.27813 15.6468 8.20957 15.7461 8.1624 15.8559C8.11523 15.9657 8.0904 16.0838 8.08937 16.2033C8.08833 16.3228 8.1111 16.4413 8.15635 16.5519C8.2016 16.6625 8.26843 16.763 8.35294 16.8475C8.43744 16.932 8.53793 16.9989 8.64853 17.0441C8.75914 17.0894 8.87765 17.1121 8.99715 17.1111C9.11665 17.1101 9.23475 17.0852 9.34455 17.0381C9.45436 16.9909 9.55367 16.9223 9.63669 16.8364L16.8367 9.63637C17.0054 9.4676 17.1002 9.23872 17.1002 9.00007C17.1002 8.76143 17.0054 8.53255 16.8367 8.36377Z" fill="#FF4A37"></path></svg>						</span>
										<span class="elementor-icon-list-text">CONTACT US</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-03e5ea2" data-id="03e5ea2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-55da414 elementor-widget elementor-widget-text-editor" data-id="55da414" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							Say hello!
<a style="color: white;" href="tel:+966 55 507 2159">+966 55 507 2159</a>						</div>
				</div>
				<div class="elementor-element elementor-element-fdb8f6e elementor-widget elementor-widget-text-editor" data-id="fdb8f6e" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Email us<br /><a style="color: white;" href="mailto:sales@salamaeng.com">sales@salamaeng.com</a></p>						</div>
				</div>
				<div class="elementor-element elementor-element-be40142 elementor-widget elementor-widget-text-editor" data-id="be40142" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							Meet Us:
11 St, First Industrial Area, Dammam
31431, Saudi Arabia
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-0d9797c elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="0d9797c" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-38fd23f" data-id="38fd23f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-dfa565c elementor-widget elementor-widget-heading" data-id="dfa565c" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">© 2025 <span style="color:#D31B34;">SALAMA ENGINEERING</span>. All Rights Reserved. Developed by <a href="https://clicktap.ae/" target="_blank">Clicktap Digital</a></h2>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3f60ba7" data-id="3f60ba7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-4a44d1a e-grid-align-right e-grid-align-mobile-center elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="4a44d1a" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook-f elementor-repeater-item-52a6077" href="https://www.facebook.com/salamaengineering" target="_blank">
						<span class="elementor-screen-only">Facebook-f</span>
						<svg class="e-font-icon-svg e-fab-facebook-f" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg"><path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-x-twitter elementor-repeater-item-b6e81c7" href="https://twitter.com/SEngIndustries" target="_blank">
						<span class="elementor-screen-only">X-twitter</span>
						<svg class="e-font-icon-svg e-fab-x-twitter" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin-in elementor-repeater-item-dd6ae78" href="https://www.linkedin.com/company/salama-engineering-industries/" target="_blank">
						<span class="elementor-screen-only">Linkedin-in</span>
						<svg class="e-font-icon-svg e-fab-linkedin-in" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-ff96607" href="https://www.instagram.com/salama.engineering/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<svg class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg>					</a>
				</span>
					</div>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		
		<div data-elementor-type="popup" data-elementor-id="1501" class="elementor elementor-1501 elementor-location-popup" data-elementor-settings="{&quot;a11y_navigation&quot;:&quot;yes&quot;,&quot;timing&quot;:[]}" data-elementor-post-type="elementor_library">
					<section class="elementor-section elementor-top-section elementor-element elementor-element-5b238d0 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5b238d0" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7af62b4" data-id="7af62b4" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-28f82cc elementor-widget elementor-widget-search" data-id="28f82cc" data-element_type="widget" data-settings="{&quot;submit_trigger&quot;:&quot;click_submit&quot;}" data-widget_type="search.default">
				<div class="elementor-widget-container">
					<search class="e-search hidden" role="search">
			<form class="e-search-form" action="https://salamaeng.com" method="get">

				
				<label class="e-search-label" for="search-28f82cc">
					<span class="elementor-screen-only">
						Search					</span>
									</label>

				<div class="e-search-input-wrapper">
					<input id="search-28f82cc" placeholder="Start search Here..." class="e-search-input" type="search" name="s" value="" autocomplete="on" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="results-28f82cc" aria-haspopup="listbox">
					<svg aria-hidden="true" class="e-font-icon-svg e-fas-times" viewBox="0 0 352 512" xmlns="http://www.w3.org/2000/svg"><path d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path></svg>										<output id="results-28f82cc" class="e-search-results-container hide-loader" aria-live="polite" aria-atomic="true" aria-label="Results for search" tabindex="0">
						<div class="e-search-results"></div>
											</output>
									</div>
				
				
				<button class="e-search-submit  " type="submit">
					
					<span class="">
						Search					</span>
				</button>
				<input type="hidden" name="e_search_props" value="28f82cc-1501">
			</form>
		</search>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
					<script type='text/javascript'>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<link rel='stylesheet' id='elementor-post-1501-css' href='https://salamaeng.com/wp-content/uploads/elementor/css/post-1501.css?ver=1739300894' media='all' />
<link rel='stylesheet' id='widget-search-css' href='https://salamaeng.com/wp-content/plugins/elementor-pro/assets/css/widget-search.min.css?ver=3.24.2' media='all' />
<script id="chaty-js-extra">
var chaty_settings = {"chaty_widgets":[{"id":0,"identifier":0,"settings":{"cta_type":"simple-view","cta_body":"","cta_head":"","cta_head_bg_color":"","cta_head_text_color":"","show_close_button":"no","position":"right","custom_position":1,"bottom_spacing":"25","side_spacing":"25","icon_view":"vertical","default_state":"open","cta_text":"","cta_text_color":"#333333","cta_bg_color":"#ffffff","show_cta":"first_click","is_pending_mesg_enabled":"0","pending_mesg_count":"","pending_mesg_count_color":"#ffffff","pending_mesg_count_bgcolor":"#dd0000","widget_icon":"chat-base","widget_icon_url":"","widget_fa_icon":"","font_family":"System Stack","widget_size":"130","custom_widget_size":"130","is_google_analytics_enabled":"off","bg_blur_effect":"off","close_text":"Hide","widget_color":"#a886cd","widget_icon_color":"#ffffff","widget_rgb_color":"168,134,205","has_custom_css":0,"custom_css":"","widget_token":"1d208625be","widget_index":"","attention_effect":""},"triggers":{"has_time_delay":1,"time_delay":0,"exit_intent":0,"has_display_after_page_scroll":0,"display_after_page_scroll":0,"auto_hide_widget":0,"hide_after":0,"show_on_pages_rules":[],"time_diff":0,"has_date_scheduling_rules":0,"date_scheduling_rules":{"start_date_time":"","end_date_time":""},"date_scheduling_rules_timezone":0,"day_hours_scheduling_rules_timezone":0,"has_day_hours_scheduling_rules":0,"day_hours_scheduling_rules":[],"day_time_diff":"","show_on_direct_visit":0,"show_on_referrer_social_network":0,"show_on_referrer_search_engines":0,"show_on_referrer_google_ads":0,"show_on_referrer_urls":[],"has_show_on_specific_referrer_urls":0,"has_traffic_source":0,"has_countries":0,"countries":[],"has_target_rules":0},"channels":[{"channel":"Whatsapp","value":"966555072159","hover_text":"Hi! I\u2019m Ahmad. How can i assist you","svg_icon":"<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#49E670\"\/><path d=\"M12.9821 10.1115C12.7029 10.7767 11.5862 11.442 10.7486 11.575C10.1902 11.7081 9.35269 11.8411 6.84003 10.7767C3.48981 9.44628 1.39593 6.25317 1.25634 6.12012C1.11674 5.85403 2.13001e-06 4.39053 2.13001e-06 2.92702C2.13001e-06 1.46351 0.83755 0.665231 1.11673 0.399139C1.39592 0.133046 1.8147 1.01506e-06 2.23348 1.01506e-06C2.37307 1.01506e-06 2.51267 1.01506e-06 2.65226 1.01506e-06C2.93144 1.01506e-06 3.21063 -2.02219e-06 3.35022 0.532183C3.62941 1.19741 4.32736 2.66092 4.32736 2.79397C4.46696 2.92702 4.46696 3.19311 4.32736 3.32616C4.18777 3.59225 4.18777 3.59224 3.90858 3.85834C3.76899 3.99138 3.6294 4.12443 3.48981 4.39052C3.35022 4.52357 3.21063 4.78966 3.35022 5.05576C3.48981 5.32185 4.18777 6.38622 5.16491 7.18449C6.42125 8.24886 7.39839 8.51496 7.81717 8.78105C8.09636 8.91409 8.37554 8.9141 8.65472 8.648C8.93391 8.38191 9.21309 7.98277 9.49228 7.58363C9.77146 7.31754 10.0507 7.1845 10.3298 7.31754C10.609 7.45059 12.2841 8.11582 12.5633 8.38191C12.8425 8.51496 13.1217 8.648 13.1217 8.78105C13.1217 8.78105 13.1217 9.44628 12.9821 10.1115Z\" transform=\"translate(12.9597 12.9597)\" fill=\"#FAFAFA\"\/><path d=\"M0.196998 23.295L0.131434 23.4862L0.323216 23.4223L5.52771 21.6875C7.4273 22.8471 9.47325 23.4274 11.6637 23.4274C18.134 23.4274 23.4274 18.134 23.4274 11.6637C23.4274 5.19344 18.134 -0.1 11.6637 -0.1C5.19344 -0.1 -0.1 5.19344 -0.1 11.6637C-0.1 13.9996 0.624492 16.3352 1.93021 18.2398L0.196998 23.295ZM5.87658 19.8847L5.84025 19.8665L5.80154 19.8788L2.78138 20.8398L3.73978 17.9646L3.75932 17.906L3.71562 17.8623L3.43104 17.5777C2.27704 15.8437 1.55796 13.8245 1.55796 11.6637C1.55796 6.03288 6.03288 1.55796 11.6637 1.55796C17.2945 1.55796 21.7695 6.03288 21.7695 11.6637C21.7695 17.2945 17.2945 21.7695 11.6637 21.7695C9.64222 21.7695 7.76778 21.1921 6.18227 20.039L6.17557 20.0342L6.16817 20.0305L5.87658 19.8847Z\" transform=\"translate(7.7758 7.77582)\" fill=\"white\" stroke=\"white\" stroke-width=\"0.2\"\/><\/svg>","is_desktop":1,"is_mobile":1,"icon_color":"rgba(73, 230, 112, 0)","icon_rgb_color":"73,230,112","channel_type":"Whatsapp","custom_image_url":"https:\/\/salamaeng.com\/wp-content\/uploads\/2024\/10\/Group-1171275256-1.png","order":"","pre_set_message":"","is_use_web_version":"1","is_open_new_tab":"1","is_default_open":"0","has_welcome_message":"0","emoji_picker":"1","input_placeholder":"Write your message...","chat_welcome_message":"<p>How can I help you? :)<\/p>","wp_popup_headline":"Let&#039;s chat on WhatsApp","wp_popup_nickname":"","wp_popup_profile":"","wp_popup_head_bg_color":"#4AA485","qr_code_image_url":"","mail_subject":"","channel_account_type":"personal","contact_form_settings":[],"contact_fields":[],"contact_custom_fields":[],"url":"https:\/\/web.whatsapp.com\/send?phone=966555072159","mobile_target":"","desktop_target":"_blank","target":"_blank","is_agent":"0","agent_data":[],"header_text":"","header_sub_text":"","header_bg_color":"","header_text_color":"","widget_token":"1d208625be","widget_index":"","click_event":"","is_agent_desktop":"0","is_agent_mobile":"0","v2_site_key":"","v3_site_key":"","enable_recaptcha":"0","hide_recaptcha_badge":"no","viber_url":""}]}],"ajax_url":"https:\/\/salamaeng.com\/wp-admin\/admin-ajax.php","data_analytics_settings":"on","page_id":"3320","product":{"title":"","sku":"","price":"","regPrice":"","discount":""},"lang":{"whatsapp_label":"WhatsApp Message","whatsapp_button":"Send WhatsApp Message","hide_whatsapp_form":"Hide WhatsApp Form","emoji_picker":"Show Emojis"}};
</script>
<script src="https://salamaeng.com/wp-content/plugins/chaty-pro/js/cht-front-script.js?ver=3.31728540281" id="chaty-js" defer data-wp-strategy="defer"></script>
<script src="https://salamaeng.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script src="https://salamaeng.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script src="https://salamaeng.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.9.8" id="swv-js"></script>
<script id="contact-form-7-js-extra">
var wpcf7 = {"api":{"root":"https:\/\/salamaeng.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
</script>
<script src="https://salamaeng.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.9.8" id="contact-form-7-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/country-phone-field-contact-form-7/assets/js/intlTelInput.min.js?ver=6.7.2" id="nbcpf-intlTelInput-script-js"></script>
<script id="nbcpf-countryFlag-script-js-extra">
var nbcpf = {"ajaxurl":"https:\/\/salamaeng.com\/wp-admin\/admin-ajax.php"};
</script>
<script src="https://salamaeng.com/wp-content/plugins/country-phone-field-contact-form-7/assets/js/countrySelect.min.js?ver=6.7.2" id="nbcpf-countryFlag-script-js"></script>
<script id="nbcpf-countryFlag-script-js-after">
		(function($) {
			$(function() {
				$(".wpcf7-countrytext").countrySelect({
					
				});
				$(".wpcf7-phonetext").intlTelInput({
					autoHideDialCode: true,
					autoPlaceholder: true,
					nationalMode: false,
					separateDialCode: true,
					hiddenInput: "full_number",
						
				});

				$(".wpcf7-phonetext").each(function () {
					var hiddenInput = $(this).attr('name');
					//console.log(hiddenInput);
					$("input[name="+hiddenInput+"-country-code]").val($(this).val());
				});
				
				$(".wpcf7-phonetext").on("countrychange", function() {
					// do something with iti.getSelectedCountryData()
					//console.log(this.value);
					var hiddenInput = $(this).attr("name");
					$("input[name="+hiddenInput+"-country-code]").val(this.value);
					
				});
					
					var isMobile = /Android.+Mobile|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
					$(".wpcf7-phonetext").on("keyup", function() {
						var dial_code = $(this).siblings(".flag-container").find(".selected-flag .selected-dial-code").text();
						
						var value   = $(this).val();
						if(value == "+")
							$(this).val("");
						else if(value.indexOf("+") == "-1")
							$(this).val(dial_code + value);
						else if(value.indexOf("+") > 0)
							$(this).val(dial_code + value.substring(dial_code.length));
					});$(".wpcf7-countrytext").on("keyup", function() {
					var country_name = $(this).siblings(".flag-dropdown").find(".country-list li.active span.country-name").text();
					if(country_name == "")
					var country_name = $(this).siblings(".flag-dropdown").find(".country-list li.highlight span.country-name").text();
					
					var value   = $(this).val();
					//console.log(country_name, value);
					$(this).val(country_name + value.substring(country_name.length));
				});
				
			});
		})(jQuery);
</script>
<script src="https://salamaeng.com/wp-content/themes/hello-elementor/assets/js/hello-frontend.min.js?ver=3.1.1" id="hello-theme-frontend-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/jet-popup/assets/js/lib/jet-plugins/jet-plugins.js?ver=2.0.6" id="jet-plugins-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/jet-popup/assets/js/lib/anime-js/anime.min.js?ver=2.0.2" id="jet-anime-js-js"></script>
<script id="jet-popup-frontend-js-extra">
var jetPopupData = {"version":"2.0.6","ajax_url":"https:\/\/salamaeng.com\/wp-admin\/admin-ajax.php","isElementor":"true"};
</script>
<script src="https://salamaeng.com/wp-content/plugins/jet-popup/assets/js/jet-popup-frontend.js?ver=2.0.6" id="jet-popup-frontend-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min.js?ver=1.2.1" id="smartmenus-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.24.2" id="elementor-pro-webpack-runtime-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.24.3" id="elementor-webpack-runtime-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.24.3" id="elementor-frontend-modules-js"></script>
<script id="elementor-pro-frontend-js-before">
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/salamaeng.com\/wp-admin\/admin-ajax.php","nonce":"dd210e04c2","urls":{"assets":"https:\/\/salamaeng.com\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/salamaeng.com\/wp-json\/"},"settings":{"lazy_load_background_images":true},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"},"x-twitter":{"title":"X"},"threads":{"title":"Threads"}},"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/salamaeng.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script src="https://salamaeng.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.24.2" id="elementor-pro-frontend-js"></script>
<script src="https://salamaeng.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.24.3","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"e_swiper_latest":true,"e_nested_atomic_repeaters":true,"e_optimized_control_loading":true,"e_onboarding":true,"theme_builder_v2":true,"hello-theme-header-footer":true,"home_screen":true,"editor_v2":true,"e_element_cache":true,"link-in-bio":true,"floating-buttons":true,"display-conditions":true,"form-submissions":true},"urls":{"assets":"https:\/\/salamaeng.com\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/salamaeng.com\/wp-admin\/admin-ajax.php"},"nonces":{"floatingButtonsClickTracking":"9b398e09be"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","hello_header_logo_type":"title","hello_header_menu_layout":"horizontal","hello_footer_logo_type":"logo"},"post":{"id":0,"title":"Page not found &#8211; Salama Engineering","excerpt":""}};
</script>
<script src="https://salamaeng.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.24.3" id="elementor-frontend-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=3.24.2" id="pro-elements-handlers-js"></script>
<script src="https://salamaeng.com/wp-content/plugins/jet-popup/includes/elementor/assets/js/jet-popup-elementor-frontend.js?ver=2.0.6" id="jet-popup-elementor-frontend-js"></script>
		<style>
			.unlimited-elements-background-overlay{
				position:absolute;
				top:0px;
				left:0px;
				width:100%;
				height:100%;
				z-index:0;
			}

			.unlimited-elements-background-overlay.uc-bg-front{
				z-index:999;
			}
		</style>

		<script type='text/javascript'>

			jQuery(document).ready(function(){

				function ucBackgroundOverlayPutStart(){

					var objBG = jQuery(".unlimited-elements-background-overlay").not(".uc-bg-attached");

					if(objBG.length == 0)
						return(false);

					objBG.each(function(index, bgElement){

						var objBgElement = jQuery(bgElement);

						var targetID = objBgElement.data("forid");

						var location = objBgElement.data("location");

						switch(location){
							case "body":
							case "body_front":
								var objTarget = jQuery("body");
							break;
							case "layout":
							case "layout_front":
								var objLayout = jQuery("*[data-id=\""+targetID+"\"]");
								var objTarget = objLayout.parents(".elementor");
								if(objTarget.length > 1)
									objTarget = jQuery(objTarget[0]);
							break;
							default:
								var objTarget = jQuery("*[data-id=\""+targetID+"\"]");
							break;
						}


						if(objTarget.length == 0)
							return(true);

						var objVideoContainer = objTarget.children(".elementor-background-video-container");

						if(objVideoContainer.length == 1)
							objBgElement.detach().insertAfter(objVideoContainer).show();
						else
							objBgElement.detach().prependTo(objTarget).show();


						var objTemplate = objBgElement.children("template");

						if(objTemplate.length){
							
					        var clonedContent = objTemplate[0].content.cloneNode(true);

					    	var objScripts = jQuery(clonedContent).find("script");
					    	if(objScripts.length)
					    		objScripts.attr("type","text/javascript");
					        
					        objBgElement.append(clonedContent);
							
							objTemplate.remove();
						}

						objBgElement.trigger("bg_attached");
						objBgElement.addClass("uc-bg-attached");

					});
				}

				ucBackgroundOverlayPutStart();

				jQuery( document ).on( 'elementor/popup/show', ucBackgroundOverlayPutStart);
				jQuery( "body" ).on( 'uc_dom_updated', ucBackgroundOverlayPutStart);

			});


		</script>
		
</body>
</html>
